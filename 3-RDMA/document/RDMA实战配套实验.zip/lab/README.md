# RDMA 软件实验配套文件

本目录配套《软件 RDMA 开发环境搭建与实战教程》。请先在两台 Ubuntu 24.04 LTS 节点上完成文档中的软件安装和 IP 配置。

## 快速使用

```bash
chmod +x setup-rxe.sh teardown-rxe.sh verify-rdma.sh
./setup-rxe.sh enp0s8 rxe0
./verify-rdma.sh
make
./verbs_probe
```

服务端：

```bash
./rdma_cm_echo server 192.168.56.101
```

客户端：

```bash
./rdma_cm_echo client 192.168.56.101
```

如果网卡名或 IP 与示例不同，请替换为实际值。`make clean` 可删除编译产物，`./teardown-rxe.sh rxe0` 可删除软件 RDMA 设备。
