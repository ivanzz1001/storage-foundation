#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <errno.h>
#include <infiniband/verbs.h>
#include <netdb.h>
#include <rdma/rdma_cma.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define DEFAULT_PORT "7472"
#define BUFFER_SIZE 256
#define CQ_DEPTH 16
#define TIMEOUT_MS 10000

struct connection {
    struct rdma_cm_id *id;
    struct ibv_pd *pd;
    struct ibv_cq *cq;
    char *send_buffer;
    char *recv_buffer;
    struct ibv_mr *send_mr;
    struct ibv_mr *recv_mr;
    bool send_done;
    bool recv_done;
};

static void fail(const char *what)
{
    perror(what);
    exit(EXIT_FAILURE);
}

static void check_zero(int rc, const char *what)
{
    if (rc != 0) {
        fail(what);
    }
}

static struct rdma_cm_event *get_event(struct rdma_event_channel *channel,
                                       enum rdma_cm_event_type expected)
{
    struct rdma_cm_event *event;

    check_zero(rdma_get_cm_event(channel, &event), "rdma_get_cm_event");
    if (event->event != expected || event->status != 0) {
        fprintf(stderr, "unexpected CM event: got=%s status=%d expected=%s\n",
                rdma_event_str(event->event), event->status,
                rdma_event_str(expected));
        exit(EXIT_FAILURE);
    }
    return event;
}

static void acknowledge(struct rdma_cm_event *event)
{
    check_zero(rdma_ack_cm_event(event), "rdma_ack_cm_event");
}

static void init_connection(struct connection *conn, struct rdma_cm_id *id)
{
    struct ibv_qp_init_attr qp_attr = {0};

    conn->id = id;
    conn->pd = ibv_alloc_pd(id->verbs);
    if (conn->pd == NULL) {
        fail("ibv_alloc_pd");
    }

    conn->cq = ibv_create_cq(id->verbs, CQ_DEPTH, NULL, NULL, 0);
    if (conn->cq == NULL) {
        fail("ibv_create_cq");
    }

    qp_attr.qp_type = IBV_QPT_RC;
    qp_attr.send_cq = conn->cq;
    qp_attr.recv_cq = conn->cq;
    qp_attr.cap.max_send_wr = 8;
    qp_attr.cap.max_recv_wr = 8;
    qp_attr.cap.max_send_sge = 1;
    qp_attr.cap.max_recv_sge = 1;
    check_zero(rdma_create_qp(id, conn->pd, &qp_attr), "rdma_create_qp");

    conn->send_buffer = calloc(1, BUFFER_SIZE);
    conn->recv_buffer = calloc(1, BUFFER_SIZE);
    if (conn->send_buffer == NULL || conn->recv_buffer == NULL) {
        fail("calloc");
    }

    conn->send_mr = ibv_reg_mr(conn->pd, conn->send_buffer, BUFFER_SIZE,
                               IBV_ACCESS_LOCAL_WRITE);
    conn->recv_mr = ibv_reg_mr(conn->pd, conn->recv_buffer, BUFFER_SIZE,
                               IBV_ACCESS_LOCAL_WRITE);
    if (conn->send_mr == NULL || conn->recv_mr == NULL) {
        fail("ibv_reg_mr");
    }
}

static void post_receive(struct connection *conn)
{
    struct ibv_sge sge = {
        .addr = (uintptr_t)conn->recv_buffer,
        .length = BUFFER_SIZE,
        .lkey = conn->recv_mr->lkey,
    };
    struct ibv_recv_wr wr = {
        .wr_id = 1,
        .sg_list = &sge,
        .num_sge = 1,
    };
    struct ibv_recv_wr *bad_wr = NULL;

    check_zero(ibv_post_recv(conn->id->qp, &wr, &bad_wr), "ibv_post_recv");
}

static void post_send(struct connection *conn, const char *message)
{
    struct ibv_sge sge;
    struct ibv_send_wr wr = {0};
    struct ibv_send_wr *bad_wr = NULL;
    size_t length;

    snprintf(conn->send_buffer, BUFFER_SIZE, "%s", message);
    length = strnlen(conn->send_buffer, BUFFER_SIZE - 1) + 1;

    sge.addr = (uintptr_t)conn->send_buffer;
    sge.length = (uint32_t)length;
    sge.lkey = conn->send_mr->lkey;

    wr.wr_id = 2;
    wr.opcode = IBV_WR_SEND;
    wr.send_flags = IBV_SEND_SIGNALED;
    wr.sg_list = &sge;
    wr.num_sge = 1;
    check_zero(ibv_post_send(conn->id->qp, &wr, &bad_wr), "ibv_post_send");
}

static int64_t monotonic_ms(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        fail("clock_gettime");
    }
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static void wait_for_completions(struct connection *conn,
                                 bool need_send, bool need_recv)
{
    const int64_t deadline = monotonic_ms() + TIMEOUT_MS;

    while ((need_send && !conn->send_done) ||
           (need_recv && !conn->recv_done)) {
        struct ibv_wc wc[4];
        int count = ibv_poll_cq(conn->cq, 4, wc);

        if (count < 0) {
            fprintf(stderr, "ibv_poll_cq failed\n");
            exit(EXIT_FAILURE);
        }
        for (int i = 0; i < count; ++i) {
            if (wc[i].status != IBV_WC_SUCCESS) {
                fprintf(stderr, "work completion failed: %s vendor_err=%u\n",
                        ibv_wc_status_str(wc[i].status), wc[i].vendor_err);
                exit(EXIT_FAILURE);
            }
            if (wc[i].opcode == IBV_WC_SEND) {
                conn->send_done = true;
            } else if (wc[i].opcode == IBV_WC_RECV) {
                conn->recv_done = true;
            }
        }
        if (monotonic_ms() >= deadline) {
            fprintf(stderr, "timed out waiting for completion\n");
            exit(EXIT_FAILURE);
        }
        if (count == 0) {
            struct timespec pause = {.tv_sec = 0, .tv_nsec = 1000000};
            nanosleep(&pause, NULL);
        }
    }
}

static void destroy_connection(struct connection *conn)
{
    if (conn->id != NULL && conn->id->qp != NULL) {
        rdma_destroy_qp(conn->id);
    }
    if (conn->send_mr != NULL) {
        ibv_dereg_mr(conn->send_mr);
    }
    if (conn->recv_mr != NULL) {
        ibv_dereg_mr(conn->recv_mr);
    }
    free(conn->send_buffer);
    free(conn->recv_buffer);
    if (conn->cq != NULL) {
        ibv_destroy_cq(conn->cq);
    }
    if (conn->pd != NULL) {
        ibv_dealloc_pd(conn->pd);
    }
}

static struct addrinfo *resolve_address(const char *host, const char *port,
                                        bool passive)
{
    struct addrinfo hints = {0};
    struct addrinfo *result = NULL;
    int rc;

    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = passive ? AI_PASSIVE : 0;
    rc = getaddrinfo(host, port, &hints, &result);
    if (rc != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rc));
        exit(EXIT_FAILURE);
    }
    return result;
}

static int run_server(const char *bind_ip, const char *port)
{
    struct rdma_event_channel *channel;
    struct rdma_cm_id *listener;
    struct rdma_cm_id *id;
    struct rdma_cm_event *event;
    struct rdma_conn_param param = {0};
    struct addrinfo *address;
    struct connection conn = {0};

    channel = rdma_create_event_channel();
    if (channel == NULL) {
        fail("rdma_create_event_channel");
    }
    check_zero(rdma_create_id(channel, &listener, NULL, RDMA_PS_TCP),
               "rdma_create_id");
    address = resolve_address(bind_ip, port, true);
    check_zero(rdma_bind_addr(listener, address->ai_addr), "rdma_bind_addr");
    freeaddrinfo(address);
    check_zero(rdma_listen(listener, 4), "rdma_listen");
    printf("server listening on %s:%s\n", bind_ip, port);

    event = get_event(channel, RDMA_CM_EVENT_CONNECT_REQUEST);
    id = event->id;
    acknowledge(event);

    init_connection(&conn, id);
    post_receive(&conn);
    param.responder_resources = 1;
    param.initiator_depth = 1;
    param.retry_count = 7;
    param.rnr_retry_count = 7;
    check_zero(rdma_accept(id, &param), "rdma_accept");
    event = get_event(channel, RDMA_CM_EVENT_ESTABLISHED);
    acknowledge(event);

    wait_for_completions(&conn, false, true);
    printf("server received: %s\n", conn.recv_buffer);
    post_send(&conn, "hello from RDMA server");
    wait_for_completions(&conn, true, true);

    event = get_event(channel, RDMA_CM_EVENT_DISCONNECTED);
    acknowledge(event);
    destroy_connection(&conn);
    rdma_destroy_id(id);
    rdma_destroy_id(listener);
    rdma_destroy_event_channel(channel);
    return EXIT_SUCCESS;
}

static int run_client(const char *server_ip, const char *port)
{
    struct rdma_event_channel *channel;
    struct rdma_cm_id *id;
    struct rdma_cm_event *event;
    struct rdma_conn_param param = {0};
    struct addrinfo *address;
    struct connection conn = {0};

    channel = rdma_create_event_channel();
    if (channel == NULL) {
        fail("rdma_create_event_channel");
    }
    check_zero(rdma_create_id(channel, &id, NULL, RDMA_PS_TCP),
               "rdma_create_id");
    address = resolve_address(server_ip, port, false);
    check_zero(rdma_resolve_addr(id, NULL, address->ai_addr, TIMEOUT_MS),
               "rdma_resolve_addr");
    freeaddrinfo(address);
    event = get_event(channel, RDMA_CM_EVENT_ADDR_RESOLVED);
    acknowledge(event);

    check_zero(rdma_resolve_route(id, TIMEOUT_MS), "rdma_resolve_route");
    event = get_event(channel, RDMA_CM_EVENT_ROUTE_RESOLVED);
    acknowledge(event);

    init_connection(&conn, id);
    post_receive(&conn);
    param.responder_resources = 1;
    param.initiator_depth = 1;
    param.retry_count = 7;
    param.rnr_retry_count = 7;
    check_zero(rdma_connect(id, &param), "rdma_connect");
    event = get_event(channel, RDMA_CM_EVENT_ESTABLISHED);
    acknowledge(event);

    post_send(&conn, "hello from RDMA client");
    wait_for_completions(&conn, true, true);
    printf("client received: %s\n", conn.recv_buffer);

    check_zero(rdma_disconnect(id), "rdma_disconnect");
    event = get_event(channel, RDMA_CM_EVENT_DISCONNECTED);
    acknowledge(event);
    destroy_connection(&conn);
    rdma_destroy_id(id);
    rdma_destroy_event_channel(channel);
    return EXIT_SUCCESS;
}

static void usage(const char *program)
{
    fprintf(stderr,
            "Usage:\n"
            "  %s server <bind-ip> [port]\n"
            "  %s client <server-ip> [port]\n",
            program, program);
}

int main(int argc, char **argv)
{
    const char *port = argc == 4 ? argv[3] : DEFAULT_PORT;

    if (argc < 3 || argc > 4) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }
    if (strcmp(argv[1], "server") == 0) {
        return run_server(argv[2], port);
    }
    if (strcmp(argv[1], "client") == 0) {
        return run_client(argv[2], port);
    }
    usage(argv[0]);
    return EXIT_FAILURE;
}
