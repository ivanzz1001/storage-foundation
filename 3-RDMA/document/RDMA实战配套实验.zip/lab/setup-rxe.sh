#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $0 <netdev> [rxe-name]" >&2
  echo "Example: $0 enp0s8 rxe0" >&2
  exit 2
}

[[ $# -ge 1 && $# -le 2 ]] || usage

netdev=$1
rxe_name=${2:-rxe0}

if ! ip link show dev "$netdev" >/dev/null 2>&1; then
  echo "ERROR: network interface '$netdev' does not exist" >&2
  exit 1
fi

if ! ip -brief address show dev "$netdev" | grep -Eq 'UP|UNKNOWN'; then
  echo "ERROR: network interface '$netdev' is not up" >&2
  exit 1
fi

sudo modprobe rdma_rxe

if rdma link show | grep -Eq "link[[:space:]]+$rxe_name/"; then
  echo "RDMA link '$rxe_name' already exists"
else
  sudo rdma link add "$rxe_name" type rxe netdev "$netdev"
fi

echo
echo "RDMA links"
rdma link show
echo
echo "Verbs devices"
ibv_devices
echo
echo "Device details"
ibv_devinfo -d "$rxe_name"
