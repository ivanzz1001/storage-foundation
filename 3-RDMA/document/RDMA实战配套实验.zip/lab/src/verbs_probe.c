#include <infiniband/verbs.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

static const char *link_layer_name(uint8_t layer)
{
    switch (layer) {
    case IBV_LINK_LAYER_INFINIBAND:
        return "InfiniBand";
    case IBV_LINK_LAYER_ETHERNET:
        return "Ethernet";
    default:
        return "unknown";
    }
}

int main(void)
{
    struct ibv_device **devices;
    int count = 0;

    devices = ibv_get_device_list(&count);
    if (devices == NULL) {
        perror("ibv_get_device_list");
        return EXIT_FAILURE;
    }

    printf("found %d RDMA device(s)\n", count);
    for (int i = 0; i < count; ++i) {
        struct ibv_context *context;
        struct ibv_device_attr device_attr;
        struct ibv_port_attr port_attr;

        printf("\ndevice %d: %s\n", i, ibv_get_device_name(devices[i]));
        context = ibv_open_device(devices[i]);
        if (context == NULL) {
            perror("ibv_open_device");
            continue;
        }

        if (ibv_query_device(context, &device_attr) != 0) {
            perror("ibv_query_device");
            ibv_close_device(context);
            continue;
        }

        printf("  firmware: %s\n", device_attr.fw_ver);
        printf("  max_qp: %d\n", device_attr.max_qp);
        printf("  max_cq: %d\n", device_attr.max_cq);
        printf("  max_mr_size: 0x%" PRIx64 "\n",
               (uint64_t)device_attr.max_mr_size);

        for (uint8_t port = 1; port <= device_attr.phys_port_cnt; ++port) {
            if (ibv_query_port(context, port, &port_attr) != 0) {
                perror("ibv_query_port");
                continue;
            }
            printf("  port %u: state=%s link_layer=%s active_mtu=%u\n",
                   port,
                   ibv_port_state_str(port_attr.state),
                   link_layer_name(port_attr.link_layer),
                   128U << port_attr.active_mtu);
        }

        ibv_close_device(context);
    }

    ibv_free_device_list(devices);
    return count > 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
