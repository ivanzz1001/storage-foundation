#!/usr/bin/env bash
set -euo pipefail

echo "Kernel: $(uname -r)"
echo
echo "Loaded RDMA modules"
lsmod | awk 'NR == 1 || /(^|_)(rdma|ib|rxe)/'
echo
echo "RDMA links"
rdma link show
echo
echo "Verbs devices"
ibv_devices
echo
echo "RDMA character devices"
ls -l /dev/infiniband 2>/dev/null || true
echo
echo "Pinned-memory limit in KiB"
ulimit -l
echo
echo "RDMA resources"
rdma resource show
