#!/usr/bin/env bash
set -euo pipefail

rxe_name=${1:-rxe0}

if rdma link show | grep -Eq "link[[:space:]]+$rxe_name/"; then
  sudo rdma link delete "$rxe_name"
  echo "Deleted RDMA link '$rxe_name'"
else
  echo "RDMA link '$rxe_name' does not exist"
fi
